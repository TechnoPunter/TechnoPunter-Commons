# TechnoPunter-Commons

## Command to create dist
python setup.py sdist

## To use in other module add following to requirements.txt
git+https://github.com/TechnoPunter/TechnoPunter-Commons.git


## Environment Variables

| Logger | LOG_PATH<br/>RESOURCE_PATH       |
|--------|----------------------------------|
| Reader | RESOURCE_PATH<br/>GENERATED_PATH |
